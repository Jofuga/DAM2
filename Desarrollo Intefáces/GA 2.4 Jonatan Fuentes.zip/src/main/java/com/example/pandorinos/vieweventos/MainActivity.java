package com.example.pandorinos.vieweventos;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import static com.example.pandorinos.vieweventos.R.color.colorPrimary;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);

        // Se instancian objetos de la view
        final LinearLayout Llayout_estrella = (LinearLayout) findViewById (R.id.Llayout_estrella);
        final Button B_fondo = (Button) findViewById (R.id.B_fondo);
        final Button B_letras = (Button) findViewById (R.id.B_letras);
        final CheckBox Check = (CheckBox) findViewById (R.id.checkBox);
        final TextView Tview_oculto = (TextView) findViewById (R.id.Tview_oculto);
        final TextView Tview_largo = (TextView) findViewById (R.id.Tview_largo);

        //Cuando pulsa botón cambia color de fondo de textview
        B_fondo.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {

                if (B_fondo.isClickable ()) {
                    Llayout_estrella.setBackgroundColor (Color.GRAY);
                }

            }
        });

        //Cuando pulsa botón cambie el color de las letras de ese botón
        B_letras.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {

                if (B_letras.isClickable ()) {
                    B_letras.setTextColor (Color.RED); }
            }


        });

        //Check, cuando es seleccionado aparece un mensaje oculto con texto.
        Check.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {

                if (Check.isChecked ()) {
                    Tview_oculto.setText ("Este es el mensaje oculto");
                } else {
                    Tview_oculto.setText ("");
                }
            }
        });


        // Se realiza clic largo pero no he sido capaz de realizarlo.
        //Tview_largo.setLongClickable (new View (Toast.makeText (getApplicationContext (),"Bien hecho!", Toast.LENGTH_LONG).show ()));



}
}