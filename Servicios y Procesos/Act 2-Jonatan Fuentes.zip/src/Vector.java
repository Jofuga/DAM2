import java.util.Arrays;
import java.util.Scanner;

public class Vector {


	public static void main(String[] args) {
		
		//Declaramos vector de 10 n�meros, num e inicializamos i=0//
		int[] valores = new int[10];
		
		int num;
		int i=0;
		
		//Clase Scanner
		Scanner sc = new Scanner(System.in);
		
		//Bucle hasta diez n�meros e imprime el array con los valores//
		do {
			System.out.println("Intro diez n�meros: ");
				num = sc.nextInt();
			
			valores[i] = num;
			i++;
		} while (i<10);
		
		System.out.println("Los valores son: ");
		System.out.println(Arrays.toString(valores));

	}

}
