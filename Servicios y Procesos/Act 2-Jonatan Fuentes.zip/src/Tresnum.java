import java.util.Scanner;

public class Tresnum {

	public static void main(String[] args) {
		
		//Declaraci�n variables//
		int num1, num2, num3;
		int mult, suma;
		
		//Clase escanner para introducir datos por teclado//
		Scanner teclado = new Scanner(System.in);

		//Mostramos en pantalla la solicitud de num1,num2,num3//
		System.out.println("Intro primer n�mero");
		num1=teclado.nextInt();
		
		System.out.println("Intro segundo n�mero");
		num2=teclado.nextInt();
		
		System.out.println("Intro tercer n�mero");
		num3=teclado.nextInt();
		
		//Multiplicaci�n y suma de n�meros//
		mult = num1*num2*num3;
		suma = num1+num2+num3;
		
		//Si num1 es positivo multiplica los tres numeros, si es negativo los suma, sino es 0//
		if ( num1 > 0)
			System.out.println("Resultado: " + mult);
		
		else if ( num1 < 0)
			System.out.println("Resultado: " + suma);
		
		else
			System.out.println("Error: Intro valor distinto a cero");
		
	}

}
