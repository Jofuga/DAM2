import java.util.Scanner;

public class Numnaturales {

	public static void main(String[] args) {
		
		//Clase escaner para leer n�mero//
		Scanner sc = new Scanner(System.in);
		
		//variable de numero introducido//
		int num1;
		
		//imprime en pantalla mensaje y lo guarda//
		System.out.println("Intro un numero entre 0 y 100");
		num1=sc.nextInt();
		
		//bucle for para recorrer de 1 a n�mero introducido por usuario de uno en uno//
		for (int i = 1; i <= num1; i++ ) {
			System.out.println(i);
		}
	}

}
