
import java.util.Scanner;

public class Semana {

	public static void main(String[] args) {
		
		//Importada Clase Scanner
		Scanner sc = new Scanner(System.in);
		
		//Cadena de strings de los dias de la semana//
		String dia []= {"Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"};
			System.out.println("Introduce un n�mero entre 1 y 7");
		
			//Variable numero de d�a e introduce d�gito//
			int numd = sc.nextInt();
			
			//Si numero es entre 1 y 7 entonces dia/semana, sino, no es dia/semana//
			if ( numd >= 1 && numd <=7) {
				System.out.println("El d�a "+numd+" es "+dia[numd-1]);
			}else{
				System.out.println("No es un d�a de la semana.");
			}
		}

	}


